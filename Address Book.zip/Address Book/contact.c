
#include "contact.h"
void initialize(AddressBook *addressbook)
{
  addressbook->contacts=NULL;
  addressbook->contactcount=0;
}

void listContacts(AddressBook *addressbook) 
{
    printf("\n==================================================== Contact List ==================================\n");
    printf("| %30s | %30s | %30s |\n", "Name", "Phone Number", "Email ID");
    printf("-----------------------------------------------------------------------------------------------------\n");

    for (int i = 0; i < addressbook->contactcount; i++) 
    {
        printf("| %30s | %30s | %30s |\n", 
                addressbook->contacts[i].name, 
                addressbook->contacts[i].phone, 
                addressbook->contacts[i].email);
    }
    
    printf("----------------------------------------------------------------------------------------------------\n");
    printf("Total Contacts: %d\n\n", addressbook->contactcount);
}

void createContact(AddressBook *addressbook) 
 {
   addressbook->contacts = realloc(addressbook->contacts, 
        (addressbook->contactcount + 1) * sizeof(Contact));
    char name[15];
    int validName = 1;
    getchar();
    printf("Enter the name : ");
    scanf("%[^\n]",name);
    // Check if name contains only alphabets and spaces
    for (int i = 0; name[i] != '\0'; i++) {
        if (!isalpha(name[i]) && name[i] != ' ') {
            validName = 0;
            break;
        }
    }

    if (!validName) {
        printf("Invalid name. Name must contain only alphabets and spaces.\n");
        return;
    } else {
        strcpy(addressbook->contacts[addressbook->contactcount].name, name);
    }

    // Validate and input the contact's phone number
    char phone[20];
    int validPhone = 1;
    getchar();
    printf("Enter the phone number: ");
    scanf("%[^\n]",phone);
    
    // Check if phone number contains only digits and has exactly 10 digits
    if (strlen(phone) != 10) {
        validPhone = 0;
    } else {
        for (int i = 0; phone[i] != '\0'; i++) {
            if (!isdigit(phone[i])) {
                validPhone = 0;
                break;
            }
        }
    }

    if (!validPhone) {
        printf("Invalid phone number. Phone number must contain exactly 10 digits.\n");
        return;
    } else {
        strcpy(addressbook->contacts[addressbook->contactcount].phone, phone);
    }   
    // Validate and input the contact's email address
    char email[50];
    int validEmail = 1;
    getchar();
    printf("Enter the Email Id: ");
    scanf("%[^\n]",email);
    
    // Check if email contains '@' and ends with '.com'
    char *at_sign = strchr(email, '@');
    char *dot_com = strstr(email, ".com");

    if (at_sign == NULL || dot_com == NULL || dot_com <= at_sign + 1) {
        validEmail = 0;
    }

    if (!validEmail) {
        printf("Invalid email format. Email must contain '@' and end with '.com'.\n");
        return;
    } else {
        strcpy(addressbook->contacts[addressbook->contactcount].email, email);
    }
    // Increase the contact count and save the contact
    addressbook->contactcount++;
    saveContact(addressbook);
    //fclose(file);
   }

void searchContact(AddressBook *addressbook) 
{
    int choice;
    printf("Search by:\n");
    printf("1. Name\n");
    printf("2. Phone\n");
    printf("3. Email\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);
    getchar();

    char search[100];
    printf("Enter search name: ");
    scanf("%[^\n]", search);
    getchar();

    int found = 0; 

    switch (choice)
    {
        case 1:
            printf("Search Results by Name:\n");
            for (int i = 0; i < addressbook->contactcount; i++) 
	    {
                if (strcmp(search, addressbook->contacts[i].name)==0)
	       	{
                    printf("Name: %s\tPhone: %s\tEmail: %s\n", addressbook->contacts[i].name,
                           addressbook->contacts[i].phone, addressbook->contacts[i].email);
                    found = 1;
                }
            }
            break;
        case 2:
            printf("Search Results by Phone:\n");
            for (int i = 0; i < addressbook->contactcount; i++)
	    {
                if (strcmp(search, addressbook->contacts[i].phone)==0)
	       	{
                    printf("Name: %s\tPhone: %s\tEmail: %s\n", addressbook->contacts[i].name,
                           addressbook->contacts[i].phone, addressbook->contacts[i].email);
                    found = 1; 
                }
            }
            break;
        case 3:
            printf("Search Results by Email:\n");
            for (int i = 0; i < addressbook->contactcount; i++)
	    {
                if (strcmp(search, addressbook->contacts[i].email)==0)
	       	{
                    printf("Name: %s\tPhone: %s\tEmail: %s\n", addressbook->contacts[i].name,
                           addressbook->contacts[i].phone, addressbook->contacts[i].email);
                    found = 1;
                }
            }
            break;
        default:
            printf("Invalid choice!\n");
    }

    if (!found)
    {
        printf("No contacts found matching the search criteria.\n");
    }
}

void editContact(AddressBook *addressbook) 
{
    if (addressbook->contactcount == 0) 
    {
        printf("No contacts available to edit.\n");
        return;
    }
    char contacttoedit[15];
    printf("Enter the name of the contact to edit: ");
    scanf(" %[^\n]",contacttoedit);

    int found = 0;
    for (int i = 0; i < addressbook->contactcount; i++) 
    {
        if (strcmp(addressbook->contacts[i].name, contacttoedit) == 0) 
        {
            found = 1;

            int editchoice;
            printf("What do you want to edit?\n");
            printf("1. Name\n");
            printf("2. Phone\n");
            printf("3. Email\n");
            printf("4. All (Name, Phone, and Email)\n");
            printf("Enter your choice: ");
            scanf("%d", &editchoice);
            getchar(); 
            switch (editchoice) 
            {
                case 1:
                    printf("Enter new name: ");
                    scanf("%[^\n]", addressbook->contacts[i].name);
                    getchar();
                    printf("Name updated successfully.\n");
                    break;
                case 2:
                    printf("Enter new phone: ");
                    scanf("%s", addressbook->contacts[i].phone);
                    printf("Phone updated successfully.\n");
                    break;
                case 3:
                    printf("Enter new email: ");
                    scanf("%s", addressbook->contacts[i].email);
                    printf("Email updated successfully.\n");
                    break;
                case 4:
                    printf("Enter new name: ");
                    scanf("%[^\n]", addressbook->contacts[i].name);
                    getchar(); 
                    printf("Enter new phone: ");
                    scanf("%s", addressbook->contacts[i].phone);
                    printf("Enter new email: ");
                    scanf("%s", addressbook->contacts[i].email);
                    printf("Name, Phone, and Email updated successfully.\n");
                    break;
                default:
                    printf("Invalid choice.\n");
                    return;
            }
            break;
        }
    }

    if (!found) 
    {
        printf("Contact not found.\n");
    } 
    else 
    {
        saveContact(addressbook); 
    }
}
void saveContact(AddressBook *addressbook)
{
    FILE*file=fopen("addressbook.csv","w");//here i use write mode to save contacts in to file
    if(file==NULL)
    {
    printf("Error opening file");
    return;
    }
    fprintf(file,"#%d#\n",addressbook -> contactcount);//print the contact count
    for (int i = 0; i < addressbook->contactcount; i++)
    {
        fprintf(file, "%s,%s,%s\n",addressbook->contacts[i].name, addressbook->contacts[i].phone, addressbook->contacts[i].email);
    }
    printf("Contacts saved successfully.\n");
    fclose(file);
}
void loadContact(AddressBook *addressbook)
{
    FILE*file=fopen("addressbook.csv","r");//opening the file in read mode
     if(file==NULL)
    {
    printf("Error opening file in writing\n" );
    return;
    }
    int i=0,id;
    fscanf(file,"#%d#\n",&addressbook->contactcount);//count the contacts from file
            addressbook -> contacts = malloc(addressbook -> contactcount * sizeof(Contact));
    if(addressbook->contactcount==0)
   {
    printf("Memory allocation failed!");
    return;
   }
   // load the contacts from file to structure memory
    for(i=0;i<=addressbook->contactcount;i++)
    {
    fscanf(file,"%[^,],%[^,],%[^\n]\n",addressbook->contacts[i].name,addressbook->contacts[i].phone, addressbook->contacts[i].email);
    }
    fclose(file);//close the file
    } 
void deleteContact(AddressBook *addressbook) 
{
    if (addressbook->contactcount == 0) 
    {
        printf("No contacts available to delete.\n");
        return;
    }

    char searchName[100];
    char searchPhone[20];
    int foundCount = 0;

    printf("Enter the name of the contact to delete: ");
    scanf(" %[^\n]", searchName);
    getchar();  // Consume newline character

    // First, search for contacts with the given name
    int possibleMatches[addressbook->contactcount];  // To store indices of matching contacts

    for (int i = 0; i < addressbook->contactcount; i++) 
    {
        if (strcmp(addressbook->contacts[i].name, searchName) == 0) 
        {
            possibleMatches[foundCount++] = i;  // Store index of matching contact
        }
    }

    if (foundCount == 0) 
    {
        printf("No contact found with the name '%s'.\n", searchName);
        return;
    } 
    else if (foundCount == 1) 
    {
        // Only one contact with the name, delete directly
        int i = possibleMatches[0];
        for (int j = i; j < addressbook->contactcount - 1; j++) 
        {
            addressbook->contacts[j] = addressbook->contacts[j + 1];
        }
        addressbook->contactcount--;
        printf("Contact '%s' deleted successfully.\n", searchName);
    } 
    else 
    {
        // Multiple contacts found with the same name, ask for phone number
        printf("Multiple contacts found with the name '%s'.\n", searchName);
        printf("Please enter the phone number of the contact to delete: ");
        scanf("%s", searchPhone);
        getchar();  // Consume newline character

        int found = 0;

        for (int k = 0; k < foundCount; k++) 
        {
            int i = possibleMatches[k];
            if (strcmp(addressbook->contacts[i].phone, searchPhone) == 0) 
            {
                found = 1;
                // Delete the contact
                for (int j = i; j < addressbook->contactcount - 1; j++) 
                {
                    addressbook->contacts[j] = addressbook->contacts[j + 1];
                }
                addressbook->contactcount--;
                printf("Contact with name '%s' and phone '%s' deleted successfully.\n", searchName, searchPhone);
                break;
            }
        }

        if (!found) 
        {
            printf("No contact found with the phone number '%s'.\n", searchPhone);
        }
    }

    // Save updated contact list
    saveContact(addressbook);
}

