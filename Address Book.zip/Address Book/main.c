#include "contact.h"
int main()
{
    AddressBook addressbook;
    initialize(&addressbook);
    loadContact(&addressbook);
    int choice;
    do {
        printf("Address Book Menu:\n");
        printf("\n1. create Contacts\n2. list Contact\n3. search Contact\n4. edit Contact\n5. Delete Contact\n6. Exit\n");
        printf("Enter your choice: ");
        fflush(stdout);  
        scanf("%d", &choice);
        switch (choice) 
         {
           case 1:
                createContact(&addressbook);
                break;
            case 2:
                listContacts(&addressbook);
                break;
            case 3:
                searchContact(&addressbook);
                break;
            case 4:
                editContact(&addressbook);
                break;
            case 5:
                deleteContact(&addressbook);
                break;
            case 6:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice, try again.\n");
                break;
        }
    } while (choice != 6);
    free(addressbook.contacts);
    return 0;
}