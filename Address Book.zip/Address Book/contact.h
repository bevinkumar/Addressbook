#ifndef CONTACT_H
#define CONTACT_H


#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>

typedef struct {
    char name[50];
    char phone[20];
    char email[50];
} Contact;

typedef struct {
    Contact *contacts;
    int contactcount;
} AddressBook;

void createContact(AddressBook *addressbook);
void searchContact(AddressBook *addressbook);
void editContact(AddressBook *addressbook);
void deleteContact(AddressBook *addressbook);
void listContacts(AddressBook *addressbook);
void initialize(AddressBook *addressbook);
void loadContact(AddressBook *addressbook);
void saveContact(AddressBook *addressbook);

#endif
